sap.ui.define([
	"app/splitapp/test/unit/controller/MasterView.controller"
], function () {
	"use strict";
});
